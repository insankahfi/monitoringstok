/**
 * ==========================================================================
 * MONITORING STOK ATL ENERGY - BACKEND SERVER
 * ==========================================================================
 * Node.js + Express. Backend adalah SATU-SATUNYA pihak yang berkomunikasi
 * dengan Mekari Jurnal API. Frontend hanya memanggil endpoint internal
 * (/api/...) di server ini dan TIDAK PERNAH menyimpan credential.
 *
 * TIDAK ADA DATABASE LOKAL. Semua data berasal dari Mekari Jurnal API.
 * ==========================================================================
 */

'use strict';

require('dotenv').config();

const express = require('express');
const axios = require('axios');
const crypto = require('crypto');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
const MEKARI_BASE_URL = 'https://api.mekari.com';

const MEKARI_HMAC_USERNAME = process.env.MEKARI_HMAC_USERNAME;
const MEKARI_HMAC_SECRET = process.env.MEKARI_HMAC_SECRET;

if (!MEKARI_HMAC_USERNAME || !MEKARI_HMAC_SECRET) {
  // Jangan pernah mencetak nilai credential, cukup peringatan bahwa ia kosong.
  console.error(
    '[FATAL] MEKARI_HMAC_USERNAME / MEKARI_HMAC_SECRET belum diset. ' +
      'Set kedua environment variable ini sebelum menjalankan server.'
  );
}

/* ==========================================================================
 * 1. KONFIGURASI TANK / STORAGE
 * ==========================================================================
 * PENTING - WAJIB ANDA SESUAIKAN:
 * Kami tidak mengetahui item_id / SKU asli di akun Mekari Jurnal Anda untuk
 * masing-masing tank. Isi "mekariItemId" dan/atau "sku" di bawah ini agar
 * setiap kartu tank bisa dicocokkan dengan data inventory yang benar dari
 * Mekari. Selama field ini masih null, kartu terkait akan tampil sebagai
 * "Data belum tersedia" (EMPTY STATE) - bukan angka palsu.
 *
 * capacityKL bersifat opsional, hanya dipakai untuk menghitung persentase
 * kapasitas tangki pada tampilan progress bar. Kosongkan (null) jika tidak
 * relevan (misal untuk kartu produk yang dihitung per satuan, bukan volume).
 * ========================================================================== */
const TANK_CONFIG = {
  rawMaterials: [
    { code: 'ST1', label: 'ST1', mekariItemId: null, sku: null, capacityKL: null },
    { code: 'ST2', label: 'ST2', mekariItemId: null, sku: null, capacityKL: null },
    { code: 'ST3', label: 'ST3', mekariItemId: null, sku: null, capacityKL: null },
    { code: 'ST4', label: 'ST4', mekariItemId: null, sku: null, capacityKL: null },
    { code: 'ST5', label: 'ST5', mekariItemId: null, sku: null, capacityKL: null },
    { code: 'ETC', label: 'ETC', mekariItemId: null, sku: null, capacityKL: null }
  ],
  products: [
    { code: 'FST1', label: 'FST1', mekariItemId: null, sku: null, capacityKL: null },
    { code: 'FST2', label: 'FST2', mekariItemId: null, sku: null, capacityKL: null },
    { code: 'TK1', label: 'TK1', mekariItemId: null, sku: null, capacityKL: null },
    { code: 'TK2', label: 'TK2', mekariItemId: null, sku: null, capacityKL: null },
    { code: 'TK3', label: 'TK3', mekariItemId: null, sku: null, capacityKL: null },
    { code: 'TK4', label: 'TK4', mekariItemId: null, sku: null, capacityKL: null }
  ]
};

/* ==========================================================================
 * 2. ENDPOINT MEKARI JURNAL API (ADAPTER - BELUM SEPENUHNYA DIKONFIRMASI)
 * ==========================================================================
 * PENTING:
 * Path di bawah ini mengikuti pola lama yang Anda berikan sebagai contoh
 * (/public/jurnal/api/v1/...). Untuk endpoint Inventory / Stock Adjustment,
 * path PASTI perlu Anda verifikasi terhadap dokumentasi resmi Mekari Jurnal
 * API yang Anda miliki, karena requirement tidak menyertakan dokumentasi
 * endpoint tersebut. Jangan jalankan fitur adjustment di production sebelum
 * path & payload berikut dipastikan benar.
 * ========================================================================== */
const MEKARI_ENDPOINTS = {
  // TODO: verifikasi - endpoint list inventory/stock balance Jurnal
  inventoryList: '/public/jurnal/api/v1/inventories',
  // TODO: verifikasi - endpoint list produk Jurnal
  productList: '/public/jurnal/api/v1/products',
  // TODO: verifikasi - endpoint detail satu item inventory
  stockDetail: (id) => `/public/jurnal/api/v1/inventories/${id}`,
  // TODO: verifikasi - endpoint untuk mengirim stock adjustment
  stockAdjustment: '/public/jurnal/api/v1/stock_adjustments'
};

/* ==========================================================================
 * 3. HMAC MEKARI/JURNAL
 * ==========================================================================
 * Mengikuti pola yang Anda jelaskan:
 *   Authorization: hmac username="USERNAME", algorithm="hmac-sha256",
 *                  headers="date request-line", signature="SIGNATURE"
 *
 * String yang ditandatangani terdiri dari header "date" dan "request-line",
 * digabung dengan newline, lalu di-HMAC-SHA256 dan di-encode Base64.
 *
 * CATATAN PENTING:
 * Karena requirement tidak menyertakan kode project lama Anda secara
 * langsung, format penggabungan persis ("date: <value>\n<request-line>")
 * mengikuti konvensi umum HMAC signing (mirip Heroku/Mekari style yang
 * Anda deskripsikan). Jika project lama Anda menggunakan format string-to-sign
 * yang sedikit berbeda (misalnya tanpa prefix "date: "), sesuaikan fungsi
 * createMekariHmac() di bawah ini agar identik dengan implementasi yang
 * sudah terbukti berhasil di project lama Anda.
 * ========================================================================== */
function createMekariHmac(method, requestPath) {
  const date = new Date().toUTCString(); // format RFC 1123, mis: "Tue, 11 Aug 2026 10:00:00 GMT"
  const requestLine = `${method.toUpperCase()} ${requestPath} HTTP/1.1`;

  // String-to-sign: gabungan header "date" dan "request-line"
  const stringToSign = `date: ${date}\n${requestLine}`;

  const signature = crypto
    .createHmac('sha256', MEKARI_HMAC_SECRET || '')
    .update(stringToSign)
    .digest('base64');

  const authorizationHeader =
    `hmac username="${MEKARI_HMAC_USERNAME}", ` +
    `algorithm="hmac-sha256", ` +
    `headers="date request-line", ` +
    `signature="${signature}"`;

  return {
    Date: date,
    Authorization: authorizationHeader
  };
}

/* ==========================================================================
 * 4. WRAPPER REQUEST KE MEKARI API
 * ========================================================================== */
async function mekariRequest(method, requestPath, { params, data } = {}) {
  if (!MEKARI_HMAC_USERNAME || !MEKARI_HMAC_SECRET) {
    return {
      ok: false,
      error: { status: 500, message: 'Server belum dikonfigurasi: credential Mekari kosong.' }
    };
  }

  const authHeaders = createMekariHmac(method, requestPath);
  const url = `${MEKARI_BASE_URL}${requestPath}`;

  try {
    const response = await axios({
      method,
      url,
      params,
      data,
      timeout: 15000, // wajib timeout, hindari request menggantung
      headers: {
        ...authHeaders,
        'Content-Type': 'application/json',
        Accept: 'application/json'
      }
    });
    return { ok: true, data: response.data };
  } catch (err) {
    return { ok: false, error: mapMekariError(err) };
  }
}

function mapMekariError(err) {
  if (err.response) {
    const status = err.response.status;
    const messages = {
      401: 'Autentikasi Mekari gagal. Periksa HMAC credential.',
      403: 'API tidak memiliki permission.',
      404: 'Data tidak ditemukan.',
      429: 'Terlalu banyak request. Silakan tunggu beberapa saat.',
      500: 'Server/API error.'
    };
    return { status, message: messages[status] || `Mekari API error (status ${status}).` };
  }
  if (err.code === 'ECONNABORTED') {
    return { status: 504, message: 'Request ke Mekari API timeout.' };
  }
  // Tidak pernah log detail error yang mungkin memuat header Authorization.
  console.error('[Mekari] Gagal terhubung ke API Mekari.');
  return { status: 502, message: 'Tidak dapat terhubung ke Mekari API.' };
}

/* ==========================================================================
 * 5. NORMALIZER - agar tahan terhadap variasi struktur response Mekari
 * ========================================================================== */
function parseNumberSafe(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function normalizeInventoryResponse(raw) {
  // Response Mekari bisa berbentuk array langsung, { data: [...] },
  // { inventories: [...] }, atau { results: [...] }. Adapter ini mencoba
  // beberapa kemungkinan agar tidak mudah rusak jika struktur berubah.
  const list = Array.isArray(raw)
    ? raw
    : raw?.data ?? raw?.inventories ?? raw?.results ?? raw?.products ?? [];

  if (!Array.isArray(list)) return [];

  return list.map((item) => ({
    id: item.id ?? item.inventory_id ?? item.item_id ?? item.product_id ?? null,
    sku: item.sku ?? item.code ?? item.item_code ?? item.product_code ?? null,
    name: item.name ?? item.item_name ?? item.product_name ?? '-',
    qty: parseNumberSafe(
      item.qty ?? item.quantity ?? item.stock_quantity ?? item.balance ?? item.available_qty
    ),
    unit: item.unit ?? item.uom ?? item.unit_name ?? '-',
    location: item.warehouse ?? item.location ?? item.warehouse_name ?? null,
    lastUpdate: item.updated_at ?? item.last_update ?? item.modified_at ?? null
  }));
}

/**
 * Cocokkan item hasil normalisasi Mekari dengan konfigurasi tank/storage
 * di TANK_CONFIG berdasarkan mekariItemId atau sku.
 */
function mergeWithTankConfig(configList, normalizedItems) {
  return configList.map((cfg) => {
    if (!cfg.mekariItemId && !cfg.sku) {
      return {
        code: cfg.code,
        label: cfg.label,
        available: false, // belum dikonfigurasi
        message: 'Data belum tersedia (belum dikonfigurasi)',
        capacityKL: cfg.capacityKL
      };
    }

    const match = normalizedItems.find(
      (item) =>
        (cfg.mekariItemId && String(item.id) === String(cfg.mekariItemId)) ||
        (cfg.sku && item.sku && String(item.sku) === String(cfg.sku))
    );

    if (!match) {
      return {
        code: cfg.code,
        label: cfg.label,
        available: false,
        message: 'Data belum tersedia',
        capacityKL: cfg.capacityKL
      };
    }

    const percentage =
      cfg.capacityKL && match.qty != null
        ? Math.max(0, Math.min(100, Math.round((match.qty / cfg.capacityKL) * 100)))
        : null;

    return {
      code: cfg.code,
      label: cfg.label,
      available: true,
      id: match.id,
      sku: match.sku,
      name: match.name,
      qty: match.qty,
      unit: match.unit,
      location: match.location,
      lastUpdate: match.lastUpdate,
      capacityKL: cfg.capacityKL,
      percentage,
      status: computeStatus(match.qty, percentage)
    };
  });
}

function computeStatus(qty, percentage) {
  if (qty == null) return 'grey';
  const ref = percentage != null ? percentage : null;
  if (ref == null) return qty > 0 ? 'green' : 'grey';
  if (ref <= 0) return 'grey';
  if (ref < 25) return 'red';
  if (ref < 60) return 'yellow';
  return 'green';
}

/* ==========================================================================
 * 6. FUNGSI DATA (dipanggil oleh route handler)
 * ========================================================================== */
async function getInventory() {
  const result = await mekariRequest('GET', MEKARI_ENDPOINTS.inventoryList);
  if (!result.ok) return result;
  return { ok: true, data: normalizeInventoryResponse(result.data) };
}

async function getProducts() {
  const inv = await getInventory();
  if (!inv.ok) return inv;
  const merged = mergeWithTankConfig(TANK_CONFIG.products, inv.data);
  return { ok: true, data: merged };
}

async function getRawMaterials() {
  const inv = await getInventory();
  if (!inv.ok) return inv;
  const merged = mergeWithTankConfig(TANK_CONFIG.rawMaterials, inv.data);
  return { ok: true, data: merged };
}

function findTankConfig(code) {
  return (
    TANK_CONFIG.rawMaterials.find((t) => t.code === code) ||
    TANK_CONFIG.products.find((t) => t.code === code)
  );
}

async function getStockDetail(code) {
  const cfg = findTankConfig(code);
  if (!cfg) return { ok: false, error: { status: 404, message: 'Tank/kode tidak dikenal.' } };

  if (!cfg.mekariItemId) {
    return {
      ok: false,
      error: { status: 404, message: 'Tank ini belum dikonfigurasi (mekariItemId kosong).' }
    };
  }

  const result = await mekariRequest('GET', MEKARI_ENDPOINTS.stockDetail(cfg.mekariItemId));
  if (!result.ok) return result;

  const normalized = normalizeInventoryResponse(
    Array.isArray(result.data) ? result.data : [result.data?.data ?? result.data]
  );
  const detail = normalized[0] || null;

  return {
    ok: true,
    data: {
      code: cfg.code,
      label: cfg.label,
      capacityKL: cfg.capacityKL,
      ...detail
    }
  };
}

/**
 * PENTING: fungsi ini benar-benar mengirim write request ke Mekari Jurnal.
 * Payload di bawah adalah payload GENERIK / ASUMSI karena requirement tidak
 * menyertakan dokumentasi resmi endpoint stock adjustment Mekari Jurnal.
 * TODO: sesuaikan struktur payload berikut dengan dokumentasi resmi Anda
 * sebelum digunakan di production.
 */
async function adjustStock({ code, qtyPhysical, note }) {
  const cfg = findTankConfig(code);
  if (!cfg) return { ok: false, error: { status: 404, message: 'Tank/kode tidak dikenal.' } };

  if (!cfg.mekariItemId) {
    return {
      ok: false,
      error: {
        status: 400,
        message: 'Tank belum dikonfigurasi (mekariItemId kosong). Lengkapi TANK_CONFIG.'
      }
    };
  }

  // TODO: struktur payload berikut ASUMSI - sesuaikan dengan dokumentasi
  // resmi endpoint Stock Adjustment Mekari Jurnal API Anda.
  const payload = {
    inventory_id: cfg.mekariItemId,
    physical_quantity: qtyPhysical,
    note: note || ''
  };

  const result = await mekariRequest('POST', MEKARI_ENDPOINTS.stockAdjustment, { data: payload });
  return result;
}

/* ==========================================================================
 * 7. ROUTES - INTERNAL API UNTUK FRONTEND
 * ========================================================================== */
app.get('/api/raw-materials', async (req, res) => {
  const result = await getRawMaterials();
  if (!result.ok) return res.status(result.error.status).json({ error: result.error.message });
  res.json({ data: result.data, fetchedAt: new Date().toISOString() });
});

app.get('/api/products', async (req, res) => {
  const result = await getProducts();
  if (!result.ok) return res.status(result.error.status).json({ error: result.error.message });
  res.json({ data: result.data, fetchedAt: new Date().toISOString() });
});

app.get('/api/inventory', async (req, res) => {
  const raw = await getRawMaterials();
  const products = await getProducts();
  if (!raw.ok) return res.status(raw.error.status).json({ error: raw.error.message });
  if (!products.ok) return res.status(products.error.status).json({ error: products.error.message });
  res.json({
    rawMaterials: raw.data,
    products: products.data,
    fetchedAt: new Date().toISOString()
  });
});

app.get('/api/stock/:id', async (req, res) => {
  const result = await getStockDetail(req.params.id);
  if (!result.ok) return res.status(result.error.status).json({ error: result.error.message });
  res.json({ data: result.data });
});

app.post('/api/stock-adjust', async (req, res) => {
  const { code, qtyPhysical, note } = req.body || {};

  if (!code || typeof code !== 'string') {
    return res.status(400).json({ error: 'Parameter "code" wajib diisi.' });
  }
  const qty = Number(qtyPhysical);
  if (!Number.isFinite(qty)) {
    return res.status(400).json({ error: 'Parameter "qtyPhysical" harus berupa angka.' });
  }

  const result = await adjustStock({ code, qtyPhysical: qty, note });
  if (!result.ok) return res.status(result.error.status).json({ error: result.error.message });

  res.json({ success: true, data: result.data });
});

/* ==========================================================================
 * 8. FALLBACK & START SERVER
 * ========================================================================== */
app.use((req, res, next) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'Endpoint tidak ditemukan.' });
  }
  next();
});

app.use((err, req, res, next) => {
  // Jangan pernah mengembalikan detail internal / secret ke client.
  console.error('[Server] Unhandled error.');
  res.status(500).json({ error: 'Terjadi kesalahan pada server.' });
});

app.listen(PORT, () => {
  console.log(`ATL Energy Stock Monitoring server running on port ${PORT}`);
});
