/**
 * ATL Energy Stock Monitoring - Frontend
 * Vanilla JS, tanpa framework. Semua data diambil dari endpoint internal
 * (/api/...) yang di-proxy oleh backend ke Mekari Jurnal API.
 */

(function () {
  'use strict';

  const REFRESH_INTERVAL_MS = 30000;

  const el = {
    rawGrid: document.getElementById('rawMaterialsGrid'),
    productGrid: document.getElementById('productsGrid'),
    lastUpdate: document.getElementById('lastUpdate'),
    refreshBtn: document.getElementById('refreshBtn'),
    loadingBar: document.getElementById('loadingBar'),
    globalError: document.getElementById('globalError'),

    modal: document.getElementById('detailModal'),
    modalTitle: document.getElementById('modalTitle'),
    modalBody: document.getElementById('modalBody'),
    modalClose: document.getElementById('modalClose'),

    opnameForm: document.getElementById('opnameForm'),
    opnameQtySistem: document.getElementById('opnameQtySistem'),
    opnameQtyFisik: document.getElementById('opnameQtyFisik'),
    opnameSelisih: document.getElementById('opnameSelisih'),
    opnameNote: document.getElementById('opnameNote'),
    opnameMessage: document.getElementById('opnameMessage'),

    confirmModal: document.getElementById('confirmModal'),
    confirmText: document.getElementById('confirmText'),
    confirmCancel: document.getElementById('confirmCancel'),
    confirmSubmit: document.getElementById('confirmSubmit')
  };

  let isFetching = false; // mencegah request tumpang tindih
  let currentDetail = null; // data tank yang sedang dibuka di modal

  /* ------------------------------------------------------------------ */
  /* Data fetching                                                       */
  /* ------------------------------------------------------------------ */

  async function loadDashboard() {
    if (isFetching) return; // hindari race condition saat auto-refresh
    isFetching = true;
    setLoading(true);
    hideGlobalError();

    try {
      const res = await fetch('/api/inventory');
      const body = await res.json();

      if (!res.ok) {
        showGlobalError(body.error || 'Gagal mengambil data.');
        return;
      }

      renderCards(el.rawGrid, body.rawMaterials || []);
      renderCards(el.productGrid, body.products || []);
      updateLastUpdate();
    } catch (err) {
      showGlobalError('Tidak dapat terhubung ke server.');
    } finally {
      isFetching = false;
      setLoading(false);
    }
  }

  async function fetchStockDetail(code) {
    const res = await fetch(`/api/stock/${encodeURIComponent(code)}`);
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || 'Gagal mengambil detail.');
    return body.data;
  }

  async function submitStockAdjust(payload) {
    const res = await fetch('/api/stock-adjust', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || 'Gagal mengirim adjustment.');
    return body;
  }

  /* ------------------------------------------------------------------ */
  /* Rendering                                                            */
  /* ------------------------------------------------------------------ */

  function renderCards(container, items) {
    container.innerHTML = '';
    items.forEach((item) => {
      container.appendChild(buildCard(item));
    });
  }

  function buildCard(item) {
    const card = document.createElement('div');
    const isEmpty = !item.available;
    card.className = 'tank-card' + (isEmpty ? ' empty' : '');
    card.dataset.code = item.code;

    const status = item.status || 'grey';

    const qtyDisplay = isEmpty
      ? 'Data belum tersedia'
      : item.qty != null
      ? formatNumber(item.qty)
      : 'Data belum tersedia';

    const unitDisplay = !isEmpty && item.qty != null ? escapeHtml(item.unit || '') : '';

    const percentBlock =
      !isEmpty && item.percentage != null
        ? `
          <div class="progress-track">
            <div class="progress-fill status-${status}" style="width:${item.percentage}%"></div>
          </div>
          <div class="percentage-label">${item.percentage}%</div>
        `
        : '';

    card.innerHTML = `
      <span class="status-dot status-${status}"></span>
      <div class="code">${escapeHtml(item.label || item.code)}</div>
      <div class="item-name">${isEmpty ? '' : escapeHtml(item.name || '-')}</div>
      <div class="qty-line">
        <span class="qty-value">${escapeHtml(String(qtyDisplay))}</span>
        <span class="qty-unit">${unitDisplay}</span>
      </div>
      ${percentBlock}
    `;

    card.addEventListener('click', () => openDetailModal(item));
    return card;
  }

  /* ------------------------------------------------------------------ */
  /* Modal detail + stock opname                                         */
  /* ------------------------------------------------------------------ */

  async function openDetailModal(item) {
    currentDetail = item;
    el.modalTitle.textContent = item.label || item.code;
    el.modalBody.innerHTML = '<p class="empty-state">Memuat detail...</p>';
    el.opnameMessage.classList.add('hidden');
    el.opnameForm.reset();
    show(el.modal);

    if (!item.available) {
      el.modalBody.innerHTML = '<p class="empty-state">Data belum tersedia dari Mekari untuk tank ini.</p>';
      el.opnameQtySistem.textContent = '-';
      el.opnameSelisih.textContent = '-';
      return;
    }

    try {
      const detail = await fetchStockDetail(item.code);
      renderModalBody(detail || item);
      el.opnameQtySistem.textContent = formatQtyUnit(item.qty, item.unit);
      el.opnameSelisih.textContent = '-';
    } catch (err) {
      // fallback ke data ringkas yang sudah ada dari dashboard
      renderModalBody(item);
      el.opnameQtySistem.textContent = formatQtyUnit(item.qty, item.unit);
    }
  }

  function renderModalBody(detail) {
    const rows = [
      ['Item', detail.name],
      ['SKU', detail.sku],
      ['Qty Sistem', detail.qty != null ? formatQtyUnit(detail.qty, detail.unit) : null],
      ['Gudang/Lokasi', detail.location],
      ['Last Update', formatDateTime(detail.lastUpdate)],
      ['Kapasitas Tank', detail.capacityKL != null ? `${detail.capacityKL} KL` : null]
    ].filter(([, value]) => value !== null && value !== undefined && value !== '');

    el.modalBody.innerHTML = rows
      .map(
        ([label, value]) => `
        <div class="detail-row">
          <span class="label">${escapeHtml(label)}</span>
          <span class="value">${escapeHtml(String(value))}</span>
        </div>`
      )
      .join('');

    if (rows.length === 0) {
      el.modalBody.innerHTML = '<p class="empty-state">Data belum tersedia.</p>';
    }
  }

  function closeModal() {
    hide(el.modal);
    currentDetail = null;
  }

  el.modalClose.addEventListener('click', closeModal);
  el.modal.addEventListener('click', (e) => {
    if (e.target === el.modal) closeModal();
  });

  el.opnameQtyFisik.addEventListener('input', () => {
    if (!currentDetail || currentDetail.qty == null) return;
    const fisik = Number(el.opnameQtyFisik.value);
    if (!Number.isFinite(fisik)) {
      el.opnameSelisih.textContent = '-';
      return;
    }
    const selisih = fisik - currentDetail.qty;
    el.opnameSelisih.textContent = formatQtyUnit(selisih, currentDetail.unit, true);
  });

  el.opnameForm.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!currentDetail) return;

    const fisik = Number(el.opnameQtyFisik.value);
    if (!Number.isFinite(fisik)) return;

    const note = el.opnameNote.value.trim();
    const selisih = currentDetail.qty != null ? fisik - currentDetail.qty : null;

    el.confirmText.textContent =
      `Kirim stock adjustment untuk ${currentDetail.label || currentDetail.code}: ` +
      `qty fisik ${formatQtyUnit(fisik, currentDetail.unit)}` +
      (selisih != null ? ` (selisih ${formatQtyUnit(selisih, currentDetail.unit, true)})` : '') +
      ' ke Mekari Jurnal. Lanjutkan?';

    show(el.confirmModal);

    el.confirmSubmit.onclick = async () => {
      hide(el.confirmModal);
      el.opnameMessage.classList.remove('hidden', 'success', 'error');
      el.opnameMessage.textContent = 'Mengirim adjustment ke Mekari...';

      try {
        await submitStockAdjust({
          code: currentDetail.code,
          qtyPhysical: fisik,
          note
        });
        el.opnameMessage.textContent = 'Berhasil dikirim ke Mekari Jurnal.';
        el.opnameMessage.classList.add('success');
        await loadDashboard(); // refresh data setelah berhasil
      } catch (err) {
        el.opnameMessage.textContent = err.message || 'Gagal mengirim adjustment.';
        el.opnameMessage.classList.add('error');
      }
    };
  });

  el.confirmCancel.addEventListener('click', () => hide(el.confirmModal));

  /* ------------------------------------------------------------------ */
  /* Refresh controls                                                     */
  /* ------------------------------------------------------------------ */

  el.refreshBtn.addEventListener('click', () => {
    loadDashboard();
  });

  function setLoading(isLoading) {
    el.loadingBar.classList.toggle('hidden', !isLoading);
    el.refreshBtn.classList.toggle('spinning', isLoading);
    el.refreshBtn.disabled = isLoading;
  }

  function updateLastUpdate() {
    const now = new Date();
    el.lastUpdate.textContent = now.toLocaleTimeString('id-ID', { hour12: false });
  }

  function showGlobalError(message) {
    el.globalError.textContent = message;
    el.globalError.classList.remove('hidden');
  }

  function hideGlobalError() {
    el.globalError.classList.add('hidden');
  }

  /* ------------------------------------------------------------------ */
  /* Helpers                                                              */
  /* ------------------------------------------------------------------ */

  function show(node) {
    node.classList.remove('hidden');
  }
  function hide(node) {
    node.classList.add('hidden');
  }

  function formatNumber(n) {
    if (n == null || !Number.isFinite(Number(n))) return '-';
    return Number(n).toLocaleString('id-ID', { maximumFractionDigits: 2 });
  }

  function formatQtyUnit(n, unit, signed) {
    if (n == null || !Number.isFinite(Number(n))) return '-';
    const sign = signed && n > 0 ? '+' : '';
    return `${sign}${formatNumber(n)}${unit ? ' ' + unit : ''}`;
  }

  function formatDateTime(value) {
    if (!value) return null;
    const d = new Date(value);
    if (isNaN(d.getTime())) return String(value);
    return d.toLocaleString('id-ID', { hour12: false });
  }

  function escapeHtml(str) {
    if (str == null) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /* ------------------------------------------------------------------ */
  /* Init                                                                 */
  /* ------------------------------------------------------------------ */

  loadDashboard();
  setInterval(loadDashboard, REFRESH_INTERVAL_MS);
})();
